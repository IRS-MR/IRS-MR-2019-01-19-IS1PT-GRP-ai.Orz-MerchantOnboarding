from django.apps import AppConfig


class MerchantonboardingConfig(AppConfig):
    name = 'merchantonboarding'
